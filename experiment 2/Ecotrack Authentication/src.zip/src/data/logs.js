const logs = [
  { activity: "Car Travel", carbon: 20 },
  { activity: "Electricity Usage", carbon: 15 },
  { activity: "Cycling", carbon: 2 },
];

export default logs;
