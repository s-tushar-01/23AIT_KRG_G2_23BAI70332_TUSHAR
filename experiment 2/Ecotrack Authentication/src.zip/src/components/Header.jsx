import { useAuth } from "../context/AuthContext";
import { useNavigate, Link } from "react-router-dom";

const Header = () => {
  const { isAuthenticated, logout } = useAuth();
  const navigate = useNavigate();

  const handleLogout = () => {
    logout();
    navigate("/login");
  };

  return (
    <header
      style={{
        padding: "1rem",
        background: "#2ecc71",
        color: "white",
        display: "flex",
        justifyContent: "space-between",
        alignItems: "center",
      }}
    >
      <h2>EcoTrack</h2>

      {isAuthenticated && (
        <div style={{ display: "flex", gap: "12px" }}>
          <Link to="/dashboard" style={{ color: "white" }}>
            Dashboard
          </Link>
          <Link to="/dashboard/summary" style={{ color: "white" }}>
            Summary
          </Link>
          <Link to="/dashboard/analytics" style={{ color: "white" }}>
            Analytics
          </Link>
          <Link to="/logs" style={{ color: "white" }}>
            Logs
          </Link>
          <button onClick={handleLogout}>Logout</button>
        </div>
      )}
    </header>
  );
};

export default Header;
