import logs from "../data/logs";

const Dashboard = () => {
  const total = logs.reduce((sum, log) => sum + log.carbon, 0);

  return (
    <div style={{ padding: "2rem" }}>
      <h2>Dashboard</h2>
      <p>Total Carbon Emission: {total}</p>
    </div>
  );
};

export default Dashboard;
