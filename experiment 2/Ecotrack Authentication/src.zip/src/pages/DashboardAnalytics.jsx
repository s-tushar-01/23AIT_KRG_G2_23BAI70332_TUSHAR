const DashboardAnalytics = () => {
  return <p>This is a dashboard Analytics.</p>;
};

export default DashboardAnalytics;
