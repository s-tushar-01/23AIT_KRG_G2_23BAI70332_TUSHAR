const DashboardSummary = () => {
  return <p>This is a dashboard Summary.</p>;
};

export default DashboardSummary;
